# 국민의 소리 - 쉬운모드 더미DB 연동 실행 설명서

TL_본회의.zip(국회 본회의 회의록) 데이터를 더미DB로 가공해서, 쉬운모드 주제 버튼과
연동한 테스트 버전이다.

## 1. 파일 구성

받은 파일들을 **모두 같은 폴더**에 넣는다.

```
프로젝트폴더/
├── rag_gui_py6_main.py     # 실행할 GUI 코드
├── dummy_db.json           # 주제별 더미DB (build_dummy_db.py 결과물)
├── build_dummy_db.py       # dummy_db.json을 만든 스크립트 (재실행 안 해도 됨)
└── assembly_background.jpg # 첫 화면 배경 사진 (기존에 쓰던 파일, 각자 준비)
```

- `dummy_db.json`은 이미 만들어진 결과물이라 그냥 넣기만 하면 된다.
- `build_dummy_db.py`는 원본 zip 데이터를 다시 가공하고 싶을 때만 필요하다 (아래 5번 참고).
- `assembly_background.jpg`는 원본 코드에서 쓰던 첫 화면 배경 이미지다. 없으면 첫 화면 배경만 회색으로 나오고 나머지 기능은 정상 동작한다.

## 2. 사전 준비

- Python 3.9 이상 권장
- PySide6 설치

```bash
pip install PySide6
```

(가상환경 쓰는 경우 먼저 활성화한 뒤 설치)

## 3. 실행

PyCharm이나 터미널에서 `rag_gui_py6_main.py`를 실행한다.

```bash
python rag_gui_py6_main.py
```

1. 첫 화면에서 **쉬운모드** 버튼 클릭
2. 상단의 주제 버튼(정치/경제/사회, 국방/안보/외교, 교육/문화/통일, 노동/사회) 중 하나 클릭
3. 아래 "요약 내용" 박스에 해당 주제의 실제 회의록 질의응답 3건이 랜덤으로 표시된다

버튼을 다시 누르면 매번 다른 3건이 랜덤으로 뽑힌다 (더미 테스트용 동작).

## 4. 정상 동작 확인 방법

- 주제 버튼 클릭 시 "불러오는 중입니다..." 문구가 잠깐 보인 뒤, 아래와 같은 형식으로 내용이 채워지면 정상이다.

```
[2022년7월25일(월)] 1. 정치․외교․통일․안보에 관한 질문  (질의: 윤상현)
Q. 중재위원회를 통해 한일 간 분쟁을 해결하는 절차를 개시하는 것에 대해 어떻게 생각하시나요?
A. 중재위원회를 통해 한일 간 분쟁을 해결하는 절차를 개시하는 것은 하나의 방안으로서...
```

- "'OO' 관련 더미데이터가 없습니다." 문구가 뜨면 `dummy_db.json`이 `rag_gui_py6_main.py`와 같은 폴더에 없거나, 경로가 잘못된 것이다. 두 파일이 같은 폴더에 있는지 다시 확인한다.

## 5. (선택) 더미DB 다시 만들기

원본 TL_본회의.zip을 새로 받았거나, 주제 분류 키워드를 바꾸고 싶으면 `build_dummy_db.py`를 다시 돌리면 된다.

1. zip 파일을 압축 해제해서 JSON들이 들어있는 폴더를 만든다.
2. `build_dummy_db.py` 상단의 경로를 본인 환경에 맞게 수정한다.

```python
EXTRACTED_DIR = "압축 푼 json 폴더 경로"
OUTPUT_PATH = "dummy_db.json을 저장할 경로"
```

3. 필요하면 주제 분류 키워드도 수정한다.

```python
TOPIC_KEYWORDS = {
    "정치/경제/사회": ["정치", "경제"],
    "국방/안보/외교": ["안보", "외교", "국방"],
    "교육/문화/통일": ["교육", "문화", "통일"],
    "노동/사회": ["사회", "노동"],
}
```

4. 실행한다.

```bash
python build_dummy_db.py
```

5. 새로 생성된 `dummy_db.json`을 `rag_gui_py6_main.py`와 같은 폴더에 넣고 다시 실행한다.

## 6. 다음 단계 (실제 벡터DB 연동 시)

지금은 주제별로 분류된 항목 중 **랜덤 3건**을 보여주는 더미 테스트 상태다.
실제 검색으로 바꾸려면 `rag_gui_py6_main.py`의 `EasyModeWindow.on_topic_selected` 안에서
`random.sample(items, ...)` 부분을 벡터DB 쿼리 결과로 교체하면 된다.

```python
# 지금 (더미)
sample = random.sample(items, k=sample_count)

# 나중 (벡터DB 연동 예시)
results = self.collection.query(query_texts=[topic_name], n_results=3)
```

"어려운 용어 설명" 박스는 현재 더미데이터에 용어 설명 항목이 없어서 안내 문구만 표시된다.
용어 설명 데이터를 추가로 확보하면 같은 방식으로 `term_box`에 연동하면 된다.
