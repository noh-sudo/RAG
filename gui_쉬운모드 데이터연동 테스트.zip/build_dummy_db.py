# -*- coding: utf-8 -*-
"""
TL_본회의.zip 안의 국회 회의록 JSON들을 읽어서
쉬운모드 4개 주제 버튼에 맞는 더미DB(json) 하나로 정리하는 스크립트.

실행: python build_dummy_db.py
입력: ./extracted (zip 압축 풀린 폴더)
출력: ./dummy_db.json
"""

import json
import glob
import re
import os

EXTRACTED_DIR = "/home/claude/extracted"
OUTPUT_PATH = "/home/claude/work/dummy_db.json"

# 쉬운모드 화면의 4개 주제 버튼과 동일한 이름을 키로 사용한다.
TOPIC_KEYWORDS = {
    "정치/경제/사회": ["정치", "경제"],
    "국방/안보/외교": ["안보", "외교", "국방"],
    "교육/문화/통일": ["교육", "문화", "통일"],
    "노동/사회": ["사회", "노동"],
}

# agenda 문자열에 섞여있는 구분기호(․ · ‧ 등)를 통일해서 비교하기 쉽게 정리
def normalize_agenda(agenda: str) -> str:
    agenda = agenda or ""
    for ch in ["․", "·", "‧", "(계속)", " "]:
        agenda = agenda.replace(ch, "")
    return agenda


def classify_agenda(agenda: str):
    """agenda 문자열을 보고 해당하는 주제 버튼 이름들을 리스트로 반환.
    (하나의 회의가 여러 주제에 걸칠 수 있어서 중복 매칭을 허용한다.)"""
    norm = normalize_agenda(agenda)
    matched = []
    for topic, keywords in TOPIC_KEYWORDS.items():
        if any(kw in norm for kw in keywords):
            matched.append(topic)
    return matched


def main():
    files = glob.glob(os.path.join(EXTRACTED_DIR, "*.json"))
    print(f"대상 파일 수: {len(files)}")

    db = {topic: [] for topic in TOPIC_KEYWORDS}
    skipped = 0

    for path in files:
        try:
            d = json.load(open(path, encoding="utf-8"))
        except Exception:
            skipped += 1
            continue

        agenda = d.get("agenda", "")
        summary = d.get("context_summary") or {}
        summary_q = (summary.get("summary_q") or "").strip()
        summary_a = (summary.get("summary_a") or "").strip()

        # 요약이 비어있는 항목은 더미DB에 넣지 않는다 (화면에 보여줄 내용이 없으므로)
        if not summary_q or not summary_a:
            skipped += 1
            continue

        topics = classify_agenda(agenda)
        if not topics:
            skipped += 1
            continue

        entry = {
            "id": d.get("id", os.path.basename(path)),
            "agenda": agenda,
            "meeting_name": d.get("meeting_name", ""),
            "date": d.get("date", ""),
            "questioner_name": d.get("questioner_name", ""),
            "summary_q": summary_q,
            "summary_a": summary_a,
        }

        for topic in topics:
            db[topic].append(entry)

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=2)

    print(f"스킵된 파일 수: {skipped}")
    print("주제별 항목 수:")
    for topic, items in db.items():
        print(f"  {topic}: {len(items)}건")
    print(f"저장 완료 -> {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
